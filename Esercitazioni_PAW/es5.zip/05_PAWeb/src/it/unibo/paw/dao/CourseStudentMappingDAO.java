package it.unibo.paw.dao;

import java.util.List;

public interface CourseStudentMappingDAO {
	// --- CRUD -------------

	public void create(int studentId, int courseId);

	public boolean delete(int studentId, int courseId);

	
	// ----------------------------------

	public List<StudentDTO> findStudentById(int courseId);
	public List<CourseDTO> findCourseById(int studentId);

	// ----------------------------------

	
	public boolean createTable();

	public boolean dropTable();
}
