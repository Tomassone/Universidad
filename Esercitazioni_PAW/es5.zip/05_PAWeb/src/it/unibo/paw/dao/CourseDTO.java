package it.unibo.paw.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CourseDTO {
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String name;
	private List<StudentDTO> alunni;
	
	public CourseDTO() {
		this.alunni = new ArrayList<StudentDTO>();
	}
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public List<StudentDTO> getAlunni() {
		return alunni;
	}

	public void setAlunni(List<StudentDTO> alunni) {
		this.alunni = alunni;
	}

}
