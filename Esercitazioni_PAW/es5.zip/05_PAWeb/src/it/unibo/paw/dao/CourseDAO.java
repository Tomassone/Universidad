package it.unibo.paw.dao;

import java.util.List;

public interface CourseDAO {

	// --- CRUD -------------

	public void create(CourseDTO course);

	public CourseDTO read(int code);

	public boolean update(CourseDTO course);

	public boolean delete(int code);

	
	// ----------------------------------

	public List<CourseDTO> findCourseByName(String name);

	// ----------------------------------

	
	public boolean createTable();

	public boolean dropTable();

}
