package it.unibo.paw;

import static org.junit.Assert.*;

import org.junit.Test;

public class YourTestHere {

	@Test
	public void doSomething() {
		fail("Not yet implemented");
	}

}
