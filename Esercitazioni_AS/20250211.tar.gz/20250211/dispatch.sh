#!/bin/bash

tail -f "/var/log/req.log" | while read IPC UTENTE COMANDO; do 
	for i in {192..254}; do
		IPS="$(snmpget xxx | shuf | head -n 1)"
		logger -p "local6.warn" -n "$IPC" _"$IPS"_"$UTENTE"_"$COMANDO"
	done
done
