#!/bin/bash

if [[ $# -ne 1 ]]; then
	echo "Numero erroneo di argomenti!"
	exit 1
fi

COMANDO="$1"
UTENTE="$(whoami)"
IPC="$(ip a | grep eth1 | grep inet | cut -d' ' -f6 | cut -d"/" -f1 )"
IP_ROUTER="172.21.21.1"

logger -p "local6.info" -n "$IP_ROUTER" _"$IPC"_"$UTENTE"_"$COMANDO"

sleep 10
 
tail -n 20-f "/var/log/req.log" | while read UTENTE_SCND COMANDO_SCND; do
	if [[ $UTENTE = $UTENTE_SCND && $COMANDO = $COMANDO_SCND ]]; then
		IP_SERVER=$(cat /var/log/ans.log | tail -n 20 | grep _'$UTENTE'_'$COMANDO' | cut -d'_' -f1 | cut -d"/" -f1 ))
		cd
		mkdir "$(date +%Y%m%d%H%M%S)"
		ssh exam@"$IP_SERVER" "/usr/local/bin/$COMANDO > COMANDO.out 2> COMANDO.err"
	fi
done
